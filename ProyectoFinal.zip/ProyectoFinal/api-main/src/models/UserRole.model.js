
const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class UserRole extends Model {}

UserRole.init({
  userId: {
    type: DataTypes.UUID,
    primaryKey: true,
    field: 'user_id',
    references: {
      model: 'users',
      key: 'id'
    }
  },
  roleId: {
    type: DataTypes.UUID,
    primaryKey: true,
    field: 'role_id',
    references: {
      model: 'roles',
      key: 'id'
    }
  }
}, {
  sequelize,
  modelName: 'UserRole',
  tableName: 'user_roles',
  timestamps: true,
  underscored: true
});

module.exports = UserRole;