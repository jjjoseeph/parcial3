const { body, param, query, validationResult } = require('express-validator');
const response = require('../network/response');

// Middleware para validación de campos
const validateRequest = (validations) => {
  return async (req, res, next) => {
    // Ejecutar todas las validaciones
    await Promise.all(validations.map(validation => validation.run(req)));

    // Verificar si hay errores
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      return next();
    }

    // Responder con errores de validación
    return response.error(
      req, 
      res, 
      'Error de validación', 
      400, 
      errors.array()
    );
  };
};

// Validadores para usuarios
const userValidators = {
  // Validación para creación de usuario
  createUser: validateRequest([
    body('first_name')
      .isString().withMessage('El nombre debe ser texto')
      .notEmpty().withMessage('El nombre es requerido')
      .isLength({ min: 2, max: 50 }).withMessage('El nombre debe tener entre 2 y 50 caracteres'),
    body('last_name')
      .isString().withMessage('El apellido debe ser texto')
      .notEmpty().withMessage('El apellido es requerido')
      .isLength({ min: 2, max: 50 }).withMessage('El apellido debe tener entre 2 y 50 caracteres'),
    body('username')
      .isString().withMessage('El nombre de usuario debe ser texto')
      .notEmpty().withMessage('El nombre de usuario es requerido')
      .isLength({ min: 3, max: 30 }).withMessage('El nombre de usuario debe tener entre 3 y 30 caracteres')
      .matches(/^[a-zA-Z0-9_]+$/).withMessage('El nombre de usuario solo puede contener letras, números y guiones bajos'),
    body('email')
      .isEmail().withMessage('Debe ser un email válido')
      .normalizeEmail(),
    body('telephone')
      .optional()
      .isString().withMessage('El teléfono debe ser texto')
      .isLength({ min: 7, max: 15 }).withMessage('El teléfono debe tener entre 7 y 15 caracteres'),
    body('bio')
      .optional()
      .isString().withMessage('La biografía debe ser texto')
      .isLength({ max: 500 }).withMessage('La biografía no debe exceder los 500 caracteres')
  ]),
  
  // Validación para actualización de usuario
  updateUser: validateRequest([
    body('first_name')
      .optional()
      .isString().withMessage('El nombre debe ser texto')
      .isLength({ min: 2, max: 50 }).withMessage('El nombre debe tener entre 2 y 50 caracteres'),
    body('last_name')
      .optional()
      .isString().withMessage('El apellido debe ser texto')
      .isLength({ min: 2, max: 50 }).withMessage('El apellido debe tener entre 2 y 50 caracteres'),
    body('telephone')
      .optional()
      .isString().withMessage('El teléfono debe ser texto')
      .isLength({ min: 7, max: 15 }).withMessage('El teléfono debe tener entre 7 y 15 caracteres'),
    body('bio')
      .optional()
      .isString().withMessage('La biografía debe ser texto')
      .isLength({ max: 500 }).withMessage('La biografía no debe exceder los 500 caracteres')
  ]),
  
  // Validación para verificar ID
  validateId: validateRequest([
    param('id')
      .isUUID(4).withMessage('ID inválido, debe ser un UUID válido')
  ])
};

// Validadores para autenticación
const authValidators = {
  // Validación para registro
  register: validateRequest([
    body('first_name')
      .isString().withMessage('El nombre debe ser texto')
      .notEmpty().withMessage('El nombre es requerido')
      .isLength({ min: 2, max: 50 }).withMessage('El nombre debe tener entre 2 y 50 caracteres'),
    body('last_name')
      .isString().withMessage('El apellido debe ser texto')
      .notEmpty().withMessage('El apellido es requerido')
      .isLength({ min: 2, max: 50 }).withMessage('El apellido debe tener entre 2 y 50 caracteres'),
    body('username')
      .isString().withMessage('El nombre de usuario debe ser texto')
      .notEmpty().withMessage('El nombre de usuario es requerido')
      .isLength({ min: 3, max: 30 }).withMessage('El nombre de usuario debe tener entre 3 y 30 caracteres')
      .matches(/^[a-zA-Z0-9_]+$/).withMessage('El nombre de usuario solo puede contener letras, números y guiones bajos'),
    body('email')
      .isEmail().withMessage('Debe ser un email válido')
      .normalizeEmail(),
    body('password')
      .isString().withMessage('La contraseña debe ser texto')
      .isLength({ min: 8 }).withMessage('La contraseña debe tener al menos 8 caracteres')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('La contraseña debe contener al menos una letra minúscula, una mayúscula y un número'),
    body('telephone')
      .optional()
      .isString().withMessage('El teléfono debe ser texto')
      .isLength({ min: 7, max: 15 }).withMessage('El teléfono debe tener entre 7 y 15 caracteres')
  ]),
  
  // Validación para login
  login: validateRequest([
    body('email')
      .isEmail().withMessage('Debe ser un email válido')
      .normalizeEmail(),
    body('password')
      .isString().withMessage('La contraseña debe ser texto')
      .notEmpty().withMessage('La contraseña es requerida')
  ]),
  
  // Validación para cambio de contraseña
  changePassword: validateRequest([
    body('currentPassword')
      .isString().withMessage('La contraseña actual debe ser texto')
      .notEmpty().withMessage('La contraseña actual es requerida'),
    body('newPassword')
      .isString().withMessage('La nueva contraseña debe ser texto')
      .isLength({ min: 8 }).withMessage('La nueva contraseña debe tener al menos 8 caracteres')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('La contraseña debe contener al menos una letra minúscula, una mayúscula y un número')
  ]),
  
  // Validación para recuperación de contraseña
  forgotPassword: validateRequest([
    body('email')
      .isEmail().withMessage('Debe ser un email válido')
      .normalizeEmail()
  ]),
  
  // Validación para restablecer contraseña
  resetPassword: validateRequest([
    body('token')
      .isString().withMessage('El token debe ser texto')
      .notEmpty().withMessage('El token es requerido'),
    body('newPassword')
      .isString().withMessage('La nueva contraseña debe ser texto')
      .isLength({ min: 8 }).withMessage('La nueva contraseña debe tener al menos 8 caracteres')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('La contraseña debe contener al menos una letra minúscula, una mayúscula y un número')
  ])
};

// Validadores para roles
const roleValidators = {
  // Validación para creación de rol
  createRole: validateRequest([
    body('name')
      .isString().withMessage('El nombre debe ser texto')
      .notEmpty().withMessage('El nombre es requerido')
      .isLength({ min: 3, max: 50 }).withMessage('El nombre debe tener entre 3 y 50 caracteres'),
    body('description')
      .isString().withMessage('La descripción debe ser texto')
      .notEmpty().withMessage('La descripción es requerida')
      .isLength({ max: 200 }).withMessage('La descripción no debe exceder los 200 caracteres')
  ]),
  
  // Validación para actualización de rol
  updateRole: validateRequest([
    body('name')
      .optional()
      .isString().withMessage('El nombre debe ser texto')
      .isLength({ min: 3, max: 50 }).withMessage('El nombre debe tener entre 3 y 50 caracteres'),
    body('description')
      .optional()
      .isString().withMessage('La descripción debe ser texto')
      .isLength({ max: 200 }).withMessage('La descripción no debe exceder los 200 caracteres')
  ]),
  
  // Validación para verificar ID
  validateId: validateRequest([
    param('id')
      .isUUID(4).withMessage('ID inválido, debe ser un UUID válido')
  ])
};

// Validadores para UserRole
const userRoleValidators = {
  // Validación para asignar rol a usuario
  assignRole: validateRequest([
    body('userId')
      .isUUID(4).withMessage('ID de usuario inválido, debe ser un UUID válido'),
    body('roleId')
      .isUUID(4).withMessage('ID de rol inválido, debe ser un UUID válido')
  ]),
  
  // Validación para parámetros de ruta
  validateParams: validateRequest([
    param('userId')
      .isUUID(4).withMessage('ID de usuario inválido, debe ser un UUID válido'),
    param('roleId')
      .isUUID(4).withMessage('ID de rol inválido, debe ser un UUID válido')
  ])
};

module.exports = {
  userValidators,
  authValidators,
  roleValidators,
  userRoleValidators
};