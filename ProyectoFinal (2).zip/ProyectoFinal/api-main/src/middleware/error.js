const response = require('../network/response');

// Middleware centralizado para manejo de errores
function errors(err, req, res, next) {
  console.error('[Error]', err);
  
  const message = err.message || 'Error interno del servidor';
  const status = err.statusCode || 500;

  // Personalizar errores según tipo o código
  if (err.name === 'SequelizeValidationError') {
    return response.error(
      req, 
      res, 
      'Error de validación de datos', 
      400, 
      err.errors.map(e => e.message)
    );
  }
  
  if (err.name === 'SequelizeUniqueConstraintError') {
    return response.error(
      req, 
      res, 
      'El registro ya existe', 
      409, 
      err.errors.map(e => e.message)
    );
  }

  if (err.name === 'JsonWebTokenError') {
    return response.error(
      req, 
      res, 
      'Token inválido', 
      401
    );
  }

  if (err.name === 'TokenExpiredError') {
    return response.error(
      req, 
      res, 
      'Token expirado', 
      401
    );
  }

  // Error por defecto
  response.error(req, res, message, status, err);
}

module.exports = errors;