const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

// Asegurar que exista el directorio para almacenar avatares
const avatarDir = path.join(process.cwd(), '/public/uploads/avatars');
if (!fs.existsSync(avatarDir)) {
  fs.mkdirSync(avatarDir, { recursive: true });
}

// Configuración de almacenamiento
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, avatarDir);
  },
  filename: function (req, file, cb) {
    // Generar nombre de archivo único con UUID
    const uniqueFileName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueFileName);
  }
});

// Filtro para aceptar solo imágenes
const fileFilter = (req, file, cb) => {
  // Verificar tipos MIME permitidos
  if (file.mimetype === 'image/jpeg' || 
      file.mimetype === 'image/png' || 
      file.mimetype === 'image/gif' || 
      file.mimetype === 'image/webp') {
    cb(null, true);
  } else {
    cb(new Error('Formato de archivo no soportado. Solo se permiten imágenes JPG, PNG, GIF y WebP.'), false);
  }
};

// Configuración de Multer
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB tamaño máximo
  },
  fileFilter: fileFilter
});

// Middleware para subir avatar de usuario
const uploadAvatar = upload.single('avatar');

// Middleware para manejar errores de Multer
const handleAvatarUploadError = (req, res, next) => {
  uploadAvatar(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      // Error de Multer
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          error: true,
          message: 'El archivo es demasiado grande. Tamaño máximo: 5MB'
        });
      }
      return res.status(400).json({
        error: true,
        message: `Error al subir archivo: ${err.message}`
      });
    } else if (err) {
      // Error personalizado o desconocido
      return res.status(400).json({
        error: true,
        message: err.message
      });
    }
    // Todo correcto
    next();
  });
};

// Función para eliminar avatar antiguo
const deleteOldAvatar = (avatarPath) => {
  if (!avatarPath) return;
  
  const fullPath = path.join(process.cwd(), avatarPath);
  
  // Verificar que el archivo existe y está dentro del directorio de avatares
  if (fs.existsSync(fullPath) && fullPath.startsWith(avatarDir)) {
    fs.unlink(fullPath, (err) => {
      if (err) console.error('Error al eliminar avatar antiguo:', err);
    });
  }
};

module.exports = {
  uploadAvatar: handleAvatarUploadError,
  deleteOldAvatar
};