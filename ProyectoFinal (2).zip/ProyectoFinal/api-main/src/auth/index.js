const { User, Auth } = require('../../models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../../config');
const response = require('../../network/response');

// Creación de tokens de acceso y refresh
const generateTokens = (user) => {
  // Token de acceso (duración corta)
  const accessToken = jwt.sign(
    { 
      id: user.id,
      email: user.email,
    },
    config.JWT_SECRET,
    { expiresIn: config.JWT_ACCESS_EXPIRATION }
  );

  // Token de refresco (duración larga)
  const refreshToken = jwt.sign(
    { id: user.id },
    config.JWT_REFRESH_SECRET,
    { expiresIn: config.JWT_REFRESH_EXPIRATION }
  );

  return { accessToken, refreshToken };
};

// Controlador de autenticación
class AuthController {

  // Registro de nuevo usuario
  static async register(req, res) {
    try {
      const { first_name, last_name, username, email, password, telephone } = req.body;

      // Verificar si el email ya está en uso
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        return response.error(req, res, 'El email ya está registrado', 400);
      }

      // Verificar si el username ya está en uso
      const existingUsername = await User.findOne({ where: { username } });
      if (existingUsername) {
        return response.error(req, res, 'El nombre de usuario ya está en uso', 400);
      }

      // Hashear la contraseña
      const hashedPassword = await bcrypt.hash(password, 10);

      // Crear usuario y autorización en una transacción
      const result = await sequelize.transaction(async (t) => {
        // Crear el usuario primero
        const newUser = await User.create({
          first_name,
          last_name,
          username,
          email,
          telephone,
          avatar: null, // Por defecto sin avatar
          bio: null // Por defecto sin biografía
        }, { transaction: t });

        // Crear la autenticación con el mismo ID que el usuario
        const auth = await Auth.create({
          id: newUser.id, // Mismo ID que el usuario
          email,
          password: hashedPassword
        }, { transaction: t });

        return { user: newUser, auth };
      });

      // Generar tokens
      const tokens = generateTokens({ id: result.user.id, email });

      // Enviar respuesta exitosa
      return response.success(req, res, {
        message: 'Usuario registrado exitosamente',
        user: {
          id: result.user.id,
          first_name: result.user.first_name,
          last_name: result.user.last_name,
          username: result.user.username,
          email: result.user.email
        },
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken
      }, 201);

    } catch (error) {
      console.error('Error al registrar usuario:', error);
      return response.error(req, res, 'Error al registrar usuario', 500, error);
    }
  }

  // Inicio de sesión
  static async login(req, res) {
    try {
      const { email, password } = req.body;

      // Buscar usuario por email
      const auth = await Auth.findOne({
        where: { email },
        include: [{
          model: User,
          attributes: ['id', 'first_name', 'last_name', 'username', 'avatar']
        }]
      });

      // Verificar si existe el usuario
      if (!auth) {
        return response.error(req, res, 'Credenciales inválidas', 401);
      }

      // Comparar contraseñas
      const isPasswordValid = await bcrypt.compare(password, auth.password);
      if (!isPasswordValid) {
        return response.error(req, res, 'Credenciales inválidas', 401);
      }

      // Generar tokens
      const tokens = generateTokens({ id: auth.id, email: auth.email });

      // Respuesta exitosa
      return response.success(req, res, {
        message: 'Inicio de sesión exitoso',
        user: {
          id: auth.User.id,
          first_name: auth.User.first_name,
          last_name: auth.User.last_name,
          username: auth.User.username,
          avatar: auth.User.avatar
        },
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken
      }, 200);

    } catch (error) {
      console.error('Error al iniciar sesión:', error);
      return response.error(req, res, 'Error al iniciar sesión', 500, error);
    }
  }

  // Cierre de sesión (invalidación de tokens)
  static async logout(req, res) {
    // Nota: Para una invalidación completa de tokens, se requeriría una lista negra
    // de tokens en base de datos o Redis. Aquí simplemente indicamos éxito al cliente.
    
    return response.success(req, res, {
      message: 'Sesión cerrada exitosamente'
    }, 200);
  }

  // Refrescar token
  static async refreshToken(req, res) {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        return response.error(req, res, 'Se requiere token de refresco', 401);
      }

      // Verificar token de refresco
      let decoded;
      try {
        decoded = jwt.verify(refreshToken, config.JWT_REFRESH_SECRET);
      } catch (err) {
        return response.error(req, res, 'Token de refresco inválido o expirado', 403);
      }

      // Buscar usuario
      const user = await User.findByPk(decoded.id, {
        include: [{
          model: Auth,
          attributes: ['email']
        }]
      });

      if (!user) {
        return response.error(req, res, 'Usuario no encontrado', 404);
      }

      // Generar nuevos tokens
      const tokens = generateTokens({ 
        id: user.id, 
        email: user.Auth.email 
      });

      // Enviar nuevos tokens
      return response.success(req, res, {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken
      }, 200);

    } catch (error) {
      console.error('Error al refrescar token:', error);
      return response.error(req, res, 'Error al refrescar token', 500, error);
    }
  }

  // Cambio de contraseña
  static async changePassword(req, res) {
    try {
      const { currentPassword, newPassword } = req.body;
      const userId = req.user.id; // Obtenido del middleware de autenticación

      // Buscar la autenticación del usuario
      const auth = await Auth.findByPk(userId);
      if (!auth) {
        return response.error(req, res, 'Usuario no encontrado', 404);
      }

      // Verificar contraseña actual
      const isPasswordValid = await bcrypt.compare(currentPassword, auth.password);
      if (!isPasswordValid) {
        return response.error(req, res, 'La contraseña actual es incorrecta', 400);
      }

      // Hashear nueva contraseña
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Actualizar contraseña
      await auth.update({ password: hashedPassword });

      return response.success(req, res, {
        message: 'Contraseña actualizada exitosamente'
      }, 200);

    } catch (error) {
      console.error('Error al cambiar contraseña:', error);
      return response.error(req, res, 'Error al cambiar contraseña', 500, error);
    }
  }

  // Solicitud de recuperación de contraseña
  static async forgotPassword(req, res) {
    try {
      const { email } = req.body;

      // Buscar usuario por email
      const auth = await Auth.findOne({ where: { email } });
      if (!auth) {
        // Por seguridad, no revelar si el email existe o no
        return response.success(req, res, {
          message: 'Si el email existe, recibirás instrucciones para restablecer tu contraseña'
        }, 200);
      }

      // Generar token temporal (24 horas)
      const resetToken = jwt.sign(
        { id: auth.id },
        config.JWT_RESET_SECRET,
        { expiresIn: '24h' }
      );

  

      return response.success(req, res, {
        message: 'Si el email existe, recibirás instrucciones para restablecer tu contraseña',
        
        token: resetToken
      }, 200);

    } catch (error) {
      console.error('Error al solicitar recuperación de contraseña:', error);
      return response.error(req, res, 'Error al procesar la solicitud', 500, error);
    }
  }

 
  static async resetPassword(req, res) {
    try {
      const { token, newPassword } = req.body;

      
      let decoded;
      try {
        decoded = jwt.verify(token, config.JWT_RESET_SECRET);
      } catch (err) {
        return response.error(req, res, 'Token inválido o expirado', 400);
      }

      
      const auth = await Auth.findByPk(decoded.id);
      if (!auth) {
        return response.error(req, res, 'Usuario no encontrado', 404);
      }

      
      const hashedPassword = await bcrypt.hash(newPassword, 10);

     
      await auth.update({ password: hashedPassword });

      return response.success(req, res, {
        message: 'Contraseña restablecida exitosamente'
      }, 200);

    } catch (error) {
      console.error('Error al restablecer contraseña:', error);
      return response.error(req, res, 'Error al restablecer contraseña', 500, error);
    }
  }

  
  static async verifyEmail(req, res) {
    try {
      const { token } = req.params;

      
      let decoded;
      try {
        decoded = jwt.verify(token, config.JWT_EMAIL_VERIFICATION_SECRET);
      } catch (err) {
        return response.error(req, res, 'Token inválido o expirado', 400);
      }

      
      
      return response.success(req, res, {
        message: 'Email verificado exitosamente'
      }, 200);

    } catch (error) {
      console.error('Error al verificar email:', error);
      return response.error(req, res, 'Error al verificar email', 500, error);
    }
  }
}

module.exports = AuthController;