// Módulo para estandarizar respuestas de la API

// Respuesta exitosa
exports.success = function (req, res, data, status = 200) {
  res.status(status).json({
    error: false,
    status: status,
    data: data
  });
};

// Respuesta de error
exports.error = function (req, res, message, status = 500, details) {
  console.error('[Response error]', details);
  
  // Estructura de respuesta de error
  const responseObj = {
    error: true,
    status: status,
    message: message
  };
  
  // Solo incluir detalles en ambientes de desarrollo
  if (details && process.env.NODE_ENV !== 'production') {
    responseObj.details = details;
  }
  
  res.status(status).json(responseObj);
};

// Respuesta paginada para listas
exports.paginated = function (req, res, data, pagination, status = 200) {
  res.status(status).json({
    error: false,
    status: status,
    pagination: {
      totalItems: pagination.totalItems,
      totalPages: pagination.totalPages,
      currentPage: pagination.currentPage,
      itemsPerPage: pagination.itemsPerPage,
      hasNextPage: pagination.hasNextPage,
      hasPreviousPage: pagination.hasPreviousPage
    },
    data: data
  });
};

// Respuesta para operaciones sin contenido
exports.empty = function (req, res, status = 204) {
  res.status(status).send();
};

// Respuesta para archivos
exports.file = function (req, res, filePath, fileName, status = 200) {
  res.status(status).download(filePath, fileName);
};

// Respuesta con redirección
exports.redirect = function (req, res, url, status = 302) {
  res.redirect(status, url);
};