// Middleware centralizado para manejo de errores en la API
const response = require('./response');

// Función para manejar errores no capturados
function errors(err, req, res, next) {
  console.error('[Error]', err);
  
  const message = err.message || 'Error interno del servidor';
  const status = err.statusCode || 500;

  // Manejo de errores específicos según tipo
  switch(err.name) {
    case 'SequelizeValidationError':
      return response.error(
        req, 
        res, 
        'Error de validación de datos', 
        400, 
        err.errors.map(e => ({ field: e.path, message: e.message }))
      );
    
    case 'SequelizeUniqueConstraintError':
      return response.error(
        req, 
        res, 
        'El registro ya existe', 
        409, 
        err.errors.map(e => ({ field: e.path, message: e.message }))
      );
      
    case 'SequelizeForeignKeyConstraintError':
      return response.error(
        req, 
        res, 
        'Error de referencia a entidad inexistente', 
        400
      );
      
    case 'SequelizeDatabaseError':
      return response.error(
        req, 
        res, 
        'Error de base de datos', 
        500
      );
      
    case 'JsonWebTokenError':
      return response.error(
        req, 
        res, 
        'Token inválido', 
        401
      );
      
    case 'TokenExpiredError':
      return response.error(
        req, 
        res, 
        'Token expirado', 
        401
      );
      
    default:
      // Ocultar detalles en producción
      const errorDetails = process.env.NODE_ENV === 'production' ? 
        'Contacte al administrador para más información' : 
        err.stack;
      
      return response.error(
        req, 
        res, 
        message, 
        status, 
        errorDetails
      );
  }
}

module.exports = errors;
