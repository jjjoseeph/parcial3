
const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcryptjs');

class Auth extends Model {
  
  async comparePassword(plainPassword) {
    return await bcrypt.compare(plainPassword, this.password);
  }

  
  async updatePassword(newPassword) {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    this.password = hashedPassword;
    return await this.save();
  }
}

Auth.init({
  id: {
    type: DataTypes.UUID,
    primaryKey: true,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  sequelize,
  modelName: 'Auth',
  tableName: 'auth',
  timestamps: true,
  underscored: true,
  hooks: {
    
    beforeCreate: async (auth) => {
      if (auth.password) {
        auth.password = await bcrypt.hash(auth.password, 10);
      }
    },
    
    beforeUpdate: async (auth) => {
      if (auth.changed('password')) {
        auth.password = await bcrypt.hash(auth.password, 10);
      }
    }
  }
});

module.exports = Auth;
