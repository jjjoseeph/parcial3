const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const config = require('../config');
const errors = require('../network/error');

// Importar rutas
const userRoutes = require('../routes/userRoutes');
const authRoutes = require('../routes/authRoutes');
const roleRoutes = require('../routes/roleRoutes');
const userRoleRoutes = require('../routes/userRoleRoutes');

// Inicialización de la aplicación
const app = express();

// Configuración de middlewares básicos
app.use(cors());
app.use(morgan('dev')); // Logging de solicitudes HTTP
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir archivos estáticos (para imágenes de avatar, etc.)
app.use('/public', express.static(process.cwd() + '/public'));

// Configuración de rutas
app.use('/api/users', userRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/roles', roleRoutes);
app.use('/api/user-roles', userRoleRoutes);

// Ruta principal para verificar que la API está funcionando
app.get('/', (req, res) => {
  res.json({
    name: config.API_NAME,
    version: config.API_VERSION,
    status: 'active',
    documentation: '/api/docs'
  });
});

// Ruta de documentación (puedes implementarla con Swagger u otra herramienta)
app.get('/api/docs', (req, res) => {
  res.json({
    message: 'La documentación de la API estará disponible próximamente'
  });
});

// Middleware para rutas no encontradas (404)
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: 'La ruta solicitada no existe'
  });
});

// Middleware para manejo centralizado de errores
app.use(errors);

module.exports = app;