// Archivo principal de inicio de la aplicación
const app = require('./app/app');
const config = require('./config');
const { sequelize } = require('./models');

async function startServer() {
  try {
    // Sincronizar modelos con la base de datos
    // En producción, es mejor usar migraciones en lugar de sync
    if (config.NODE_ENV === 'development' || config.NODE_ENV === 'test') {
      console.log('Sincronizando modelos con la base de datos...');
      await sequelize.sync({ alter: true });
      console.log('Base de datos sincronizada');
    } else {
      // Verificar conexión a la base de datos
      await sequelize.authenticate();
      console.log('Conexión a la base de datos establecida correctamente');
    }

    // Iniciar el servidor
    app.listen(config.PORT, () => {
      console.log(`===========================================`);
      console.log(`  ${config.API_NAME} v${config.API_VERSION}`);
      console.log(`  Servidor corriendo en puerto: ${config.PORT}`);
      console.log(`  Entorno: ${config.NODE_ENV}`);
      console.log(`  URL de la API: ${config.API_URL}`);
      console.log(`===========================================`);
    });
  } catch (error) {
    console.error('Error al iniciar el servidor:', error);
    process.exit(1);
  }
}

// Manejo de señales para cierre graceful
process.on('SIGINT', async () => {
  console.log('Cerrando la aplicación...');
  try {
    await sequelize.close();
    console.log('Conexión a la base de datos cerrada');
    process.exit(0);
  } catch (error) {
    console.error('Error al cerrar la aplicación:', error);
    process.exit(1);
  }
});

// Iniciar el servidor
startServer();