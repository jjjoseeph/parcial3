const express = require('express');
const router = express.Router();
const UserRoleController = require('../controllers/UserRoleController');


router.post('/', UserRoleController.assignRoleToUser);


router.get('/user/:userId', UserRoleController.getUserRoles);


router.get('/role/:roleId', UserRoleController.getUsersByRole);


router.delete('/user/:userId/role/:roleId', UserRoleController.removeRoleFromUser);


router.get('/', UserRoleController.getAllUserRoles);

module.exports = router;