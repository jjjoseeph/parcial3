// Configuración centralizada para la aplicación
require('dotenv').config();

// Constantes con valores predeterminados
const config = {
  // Información de la API
  API_NAME: process.env.API_NAME || 'API de gestión de usuarios y roles',
  API_VERSION: process.env.API_VERSION || '1.0.0',
  
  // Entorno y puerto
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: process.env.PORT || 3000,
  
  // Base de datos
  DB_HOST: process.env.DB_HOST || 'localhost',
  DB_PORT: process.env.DB_PORT || 5432,
  DB_NAME: process.env.DB_NAME || 'user_management_db',
  DB_USER: process.env.DB_USER || 'postgres',
  DB_PASSWORD: process.env.DB_PASSWORD || 'postgres',
  DB_DIALECT: process.env.DB_DIALECT || 'postgres',
  
  // JWT y seguridad
  JWT_SECRET: process.env.JWT_SECRET || 'tu_super_secreto_jwt_debe_ser_cambiado_en_produccion',
  JWT_ACCESS_EXPIRATION: process.env.JWT_ACCESS_EXPIRATION || '2h',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'otro_secreto_para_refresh_token',
  JWT_REFRESH_EXPIRATION: process.env.JWT_REFRESH_EXPIRATION || '7d',
  JWT_RESET_SECRET: process.env.JWT_RESET_SECRET || 'secreto_para_reset_password',
  JWT_EMAIL_VERIFICATION_SECRET: process.env.JWT_EMAIL_VERIFICATION_SECRET || 'secreto_para_verificacion_email',
  
  // Configuraciones de carga de archivos
  UPLOAD_PATH: process.env.UPLOAD_PATH || './public/uploads',
  MAX_FILE_SIZE: parseInt(process.env.MAX_FILE_SIZE || '5242880'), // 5MB por defecto
  
  // URLs y endpoints
  API_URL: process.env.API_URL || 'http://localhost:3000',
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:5173',
  
  // Correo electrónico (si se implementa)
  EMAIL_HOST: process.env.EMAIL_HOST,
  EMAIL_PORT: process.env.EMAIL_PORT,
  EMAIL_USER: process.env.EMAIL_USER,
  EMAIL_PASSWORD: process.env.EMAIL_PASSWORD,
  EMAIL_FROM: process.env.EMAIL_FROM || 'noreply@tuaplicacion.com',
  
  // Logging
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
  
  // Redis (si se implementa para cache o sesiones)
  REDIS_HOST: process.env.REDIS_HOST || 'localhost',
  REDIS_PORT: process.env.REDIS_PORT || 6379,
  REDIS_PASSWORD: process.env.REDIS_PASSWORD || '',
  
  // Cors
  CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
  
  // Ratios de límite de peticiones
  RATE_LIMIT_WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutos
  RATE_LIMIT_MAX: parseInt(process.env.RATE_LIMIT_MAX || '100'), // 100 peticiones por ventana
};

// Verificar secretos en producción
if (config.NODE_ENV === 'production') {
  const requiredSecrets = [
    'JWT_SECRET',
    'JWT_REFRESH_SECRET',
    'JWT_RESET_SECRET',
    'JWT_EMAIL_VERIFICATION_SECRET',
    'DB_PASSWORD'
  ];
  
  for (const secret of requiredSecrets) {
    if (
      process.env[secret] === undefined || 
      process.env[secret] === config[secret]
    ) {
      console.warn(`[ADVERTENCIA] La variable de entorno ${secret} no está configurada o usa un valor predeterminado. Esto no es seguro en producción.`);
    }
  }
}

module.exports = config;