
const { Role, User } = require('../models');

class RoleController {
  
  static async create(req, res) {
    try {
      const { name, description } = req.body;

      
      if (!name) {
        return res.status(400).json({
          error: 'El nombre del rol es requerido'
        });
      }

      
      const role = await Role.create({
        name,
        description
      });

      res.status(201).json({
        message: 'Rol creado exitosamente',
        role
      });
    } catch (error) {
      console.error('Error creando rol:', error);
      
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.status(409).json({
          error: 'Ya existe un rol con ese nombre'
        });
      }
      
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async getAll(req, res) {
    try {
      const roles = await Role.findAll({
        include: [{
          model: User,
          as: 'users',
          attributes: ['id', 'firstName', 'lastName', 'username', 'email']
        }]
      });
      
      res.json(roles);
    } catch (error) {
      console.error('Error obteniendo roles:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async getById(req, res) {
    try {
      const { id } = req.params;
      
      const role = await Role.findByPk(id, {
        include: [{
          model: User,
          as: 'users',
          attributes: ['id', 'firstName', 'lastName', 'username', 'email']
        }]
      });

      if (!role) {
        return res.status(404).json({
          error: 'Rol no encontrado'
        });
      }

      res.json(role);
    } catch (error) {
      console.error('Error obteniendo rol:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async update(req, res) {
    try {
      const { id } = req.params;
      const { name, description } = req.body;

      const role = await Role.findByPk(id);
      if (!role) {
        return res.status(404).json({
          error: 'Rol no encontrado'
        });
      }

     
      await role.update({
        name: name || role.name,
        description: description || role.description
      });

      res.json({
        message: 'Rol actualizado exitosamente',
        role
      });
    } catch (error) {
      console.error('Error actualizando rol:', error);
      
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.status(409).json({
          error: 'Ya existe un rol con ese nombre'
        });
      }
      
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;
      
      const role = await Role.findByPk(id);
      if (!role) {
        return res.status(404).json({
          error: 'Rol no encontrado'
        });
      }

      await role.destroy();

      res.json({
        message: 'Rol eliminado exitosamente'
      });
    } catch (error) {
      console.error('Error eliminando rol:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }
}

module.exports = RoleController;