const { User, Role, UserRole } = require('../models');


class UserRoleController {
  
  
  static async assignRoleToUser(req, res) {
    try {
      const { userId, roleId } = req.body;
      
      
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ 
          message: 'Usuario no encontrado' 
        });
      }
      
     
      const role = await Role.findByPk(roleId);
      if (!role) {
        return res.status(404).json({ 
          message: 'Rol no encontrado' 
        });
      }
      
      
      const existingRelation = await UserRole.findOne({
        where: { user_id: userId, role_id: roleId }
      });
      
      if (existingRelation) {
        return res.status(400).json({ 
          message: 'El usuario ya tiene este rol asignado' 
        });
      }
      
      
      const userRole = await UserRole.create({
        user_id: userId,
        role_id: roleId
      });
      
      res.status(201).json({
        message: 'Rol asignado al usuario exitosamente',
        data: userRole
      });
      
    } catch (error) {
      console.error('Error al asignar rol:', error);
      res.status(500).json({ 
        message: 'Error interno del servidor',
        error: error.message 
      });
    }
  }
  
  
  static async getUserRoles(req, res) {
    try {
      const { userId } = req.params;
      
      
      const user = await User.findByPk(userId, {
        include: [{
          model: Role,
          through: { attributes: [] }, 
          attributes: ['id', 'name', 'description']
        }]
      });
      
      if (!user) {
        return res.status(404).json({ 
          message: 'Usuario no encontrado' 
        });
      }
      
      res.status(200).json({
        message: 'Roles del usuario obtenidos exitosamente',
        data: {
          user: {
            id: user.id,
            username: user.username,
            first_name: user.first_name,
            last_name: user.last_name
          },
          roles: user.Roles
        }
      });
      
    } catch (error) {
      console.error('Error al obtener roles del usuario:', error);
      res.status(500).json({ 
        message: 'Error interno del servidor',
        error: error.message 
      });
    }
  }
  
  
  static async getUsersByRole(req, res) {
    try {
      const { roleId } = req.params;
      
      
      const role = await Role.findByPk(roleId, {
        include: [{
          model: User,
          through: { attributes: [] },
          attributes: ['id', 'username', 'first_name', 'last_name', 'email']
        }]
      });
      
      if (!role) {
        return res.status(404).json({ 
          message: 'Rol no encontrado' 
        });
      }
      
      res.status(200).json({
        message: 'Usuarios con el rol obtenidos exitosamente',
        data: {
          role: {
            id: role.id,
            name: role.name,
            description: role.description
          },
          users: role.Users
        }
      });
      
    } catch (error) {
      console.error('Error al obtener usuarios por rol:', error);
      res.status(500).json({ 
        message: 'Error interno del servidor',
        error: error.message 
      });
    }
  }
  
  
  static async removeRoleFromUser(req, res) {
    try {
      const { userId, roleId } = req.params;
      
      
      const userRole = await UserRole.findOne({
        where: { user_id: userId, role_id: roleId }
      });
      
      if (!userRole) {
        return res.status(404).json({ 
          message: 'Relación usuario-rol no encontrada' 
        });
      }
      
      
      await userRole.destroy();
      
      res.status(200).json({
        message: 'Rol removido del usuario exitosamente'
      });
      
    } catch (error) {
      console.error('Error al remover rol:', error);
      res.status(500).json({ 
        message: 'Error interno del servidor',
        error: error.message 
      });
    }
  }
  
  static async getAllUserRoles(req, res) {
    try {
      const userRoles = await UserRole.findAll({
        include: [
          {
            model: User,
            attributes: ['id', 'username', 'first_name', 'last_name']
          },
          {
            model: Role,
            attributes: ['id', 'name', 'description']
          }
        ]
      });
      
      res.status(200).json({
        message: 'Todas las relaciones usuario-rol obtenidas exitosamente',
        data: userRoles
      });
      
    } catch (error) {
      console.error('Error al obtener relaciones:', error);
      res.status(500).json({ 
        message: 'Error interno del servidor',
        error: error.message 
      });
    }
  }
}

module.exports = UserRoleController;