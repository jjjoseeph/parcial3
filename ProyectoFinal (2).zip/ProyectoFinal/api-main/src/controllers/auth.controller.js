
const { Auth, User, Role } = require('../models');

class AuthController {
  
  static async login(req, res) {
    try {
      const { email, password } = req.body;

      
      if (!email || !password) {
        return res.status(400).json({
          error: 'Email y password son requeridos'
        });
      }

      
      const auth = await Auth.findOne({ 
        where: { email },
        include: [{
          model: User,
          include: [{
            model: Role,
            as: 'roles',
            attributes: ['id', 'name', 'description']
          }]
        }]
      });

      if (!auth) {
        return res.status(401).json({
          error: 'Credenciales inválidas'
        });
      }

      
      const isValidPassword = await auth.comparePassword(password);
      if (!isValidPassword) {
        return res.status(401).json({
          error: 'Credenciales inválidas'
        });
      }

      res.json({
        message: 'Login exitoso',
        user: {
          id: auth.User.id,
          firstName: auth.User.firstName,
          lastName: auth.User.lastName,
          username: auth.User.username,
          telephone: auth.User.telephone,
          email: auth.User.email,
          avatar: auth.User.avatar,
          bio: auth.User.bio,
          roles: auth.User.roles
        }
      });
    } catch (error) {
      console.error('Error en login:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async changePassword(req, res) {
    try {
      const { userId } = req.params;
      const { currentPassword, newPassword } = req.body;

      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({
          error: 'Contraseña actual y nueva contraseña son requeridas'
        });
      }

      
      const user = await User.findByPk(userId);
      if (!user) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      
      const auth = await Auth.findByPk(userId);
      if (!auth) {
        return res.status(404).json({
          error: 'Registro de autenticación no encontrado'
        });
      }

      
      const isValidPassword = await auth.comparePassword(currentPassword);
      if (!isValidPassword) {
        return res.status(401).json({
          error: 'Contraseña actual incorrecta'
        });
      }

      
      await auth.updatePassword(newPassword);

      res.json({
        message: 'Contraseña actualizada exitosamente'
      });
    } catch (error) {
      console.error('Error cambiando contraseña:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async checkEmail(req, res) {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({
          error: 'Email es requerido'
        });
      }

      const auth = await Auth.findOne({ where: { email } });
      
      res.json({
        exists: !!auth
      });
    } catch (error) {
      console.error('Error verificando email:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }
}

module.exports = AuthController;