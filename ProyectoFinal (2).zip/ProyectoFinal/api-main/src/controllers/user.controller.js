
const { User, Auth, Role, sequelize } = require('../models');

class UserController {
  
  static async create(req, res) {
    const transaction = await sequelize.transaction();
    
    try {
      const { firstName, lastName, username, telephone, email, avatar, bio, password } = req.body;

      
      if (!firstName || !email || !password) {
        await transaction.rollback();
        return res.status(400).json({
          error: 'Los campos firstName, email y password son requeridos'
        });
      }

      
      const user = await User.create({
        firstName,
        lastName,
        username,
        telephone,
        email,
        avatar,
        bio
      }, { transaction });

      
      await Auth.create({
        id: user.id,
        email: user.email,
        password
      }, { transaction });

      await transaction.commit();

      
      const { password: _, ...userResponse } = user.toJSON();
      res.status(201).json({
        message: 'Usuario creado exitosamente',
        user: userResponse
      });
    } catch (error) {
      await transaction.rollback();
      console.error('Error creando usuario:', error);
      
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.status(409).json({
          error: 'El email o username ya existe'
        });
      }
      
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async getAll(req, res) {
    try {
      const users = await User.findAll({
        attributes: { exclude: ['password'] }, 
        include: [{
          model: Role,
          as: 'roles',
          attributes: ['id', 'name', 'description']
        }]
      });
      
      res.json(users);
    } catch (error) {
      console.error('Error obteniendo usuarios:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async getById(req, res) {
    try {
      const { id } = req.params;
      
      const user = await User.findByPk(id, {
        include: [{
          model: Role,
          as: 'roles',
          attributes: ['id', 'name', 'description']
        }]
      });

      if (!user) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      res.json(user);
    } catch (error) {
      console.error('Error obteniendo usuario:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }


  static async update(req, res) {
    try {
      const { id } = req.params;
      const { firstName, lastName, username, telephone, email, avatar, bio } = req.body;

      const user = await User.findByPk(id);
      if (!user) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

     
      await user.update({
        firstName: firstName || user.firstName,
        lastName: lastName || user.lastName,
        username: username || user.username,
        telephone: telephone || user.telephone,
        email: email || user.email,
        avatar: avatar || user.avatar,
        bio: bio || user.bio
      });

      
      if (email && email !== user.email) {
        await Auth.update(
          { email },
          { where: { id: user.id } }
        );
      }

      res.json({
        message: 'Usuario actualizado exitosamente',
        user
      });
    } catch (error) {
      console.error('Error actualizando usuario:', error);
      
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.status(409).json({
          error: 'El email o username ya existe'
        });
      }
      
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }

  
  static async delete(req, res) {
    const transaction = await sequelize.transaction();
    
    try {
      const { id } = req.params;
      
      const user = await User.findByPk(id);
      if (!user) {
        await transaction.rollback();
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      
      await user.destroy({ transaction });
      
      await transaction.commit();
      res.json({
        message: 'Usuario eliminado exitosamente'
      });
    } catch (error) {
      await transaction.rollback();
      console.error('Error eliminando usuario:', error);
      res.status(500).json({
        error: 'Error interno del servidor'
      });
    }
  }
}

module.exports = UserController;