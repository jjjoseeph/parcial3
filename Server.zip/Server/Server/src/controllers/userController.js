
controllers/userController.js
cat > controllers/userController.js << 'EOF'
const User = require('../models/user');
const Role = require('../models/role');

const userController = {
  getAllUsers: async (req, res) => {
    try {
      const users = await User.findAll({
        include: [{
          model: Role,
          through: { attributes: [] }
        }]
      });
      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error al obtener usuarios',
        error: error.message
      });
    }
  },

  getUserById: async (req, res) => {
    try {
      const user = await User.findByPk(req.params.id, {
        include: [{
          model: Role,
          through: { attributes: [] }
        }]
      });
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Usuario no encontrado'
        });
      }
      
      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error al obtener usuario',
        error: error.message
      });
    }
  },

  createUser: async (req, res) => {
    try {
      const { first_name, last_name, username, telephone, email, avatar, bio } = req.body;
      
      const newUser = await User.create({
        first_name,
        last_name,
        username,
        telephone,
        email,
        avatar,
        bio
      });
      
      res.status(201).json({
        success: true,
        data: newUser,
        message: 'Usuario creado exitosamente'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: 'Error al crear usuario',
        error: error.message
      });
    }
  },

  updateUser: async (req, res) => {
    try {
      const { id } = req.params;
      const { first_name, last_name, username, telephone, email, avatar, bio } = req.body;
      
      await User.update({
        first_name,
        last_name,
        username,
        telephone,
        email,
        avatar,
        bio
      }, {
        where: { id }
      });
      
      const updatedUser = await User.findByPk(id);
      
      res.json({
        success: true,
        data: updatedUser,
        message: 'Usuario actualizado exitosamente'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: 'Error al actualizar usuario',
        error: error.message
      });
    }
  },

  deleteUser: async (req, res) => {
    try {
      const { id } = req.params;
      
      const deleted = await User.destroy({
        where: { id }
      });
      
      if (!deleted) {
        return res.status(404).json({
          success: false,
          message: 'Usuario no encontrado'
        });
      }
      
      res.json({
        success: true,
        message: 'Usuario eliminado exitosamente'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error al eliminar usuario',
        error: error.message
      });
    }
  },

  assignRole: async (req, res) => {
    try {
      const { userId } = req.params;
      const { roleId } = req.body;
      
      const user = await User.findByPk(userId);
      const role = await Role.findByPk(roleId);
      
      if (!user || !role) {
        return res.status(404).json({
          success: false,
          message: 'Usuario o rol no encontrado'
        });
      }
      
      await user.addRole(role);
      
      res.json({
        success: true,
        message: 'Rol asignado exitosamente'
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: 'Error al asignar rol',
        error: error.message
      });
    }
  }
};

module.exports = userController;
EOF