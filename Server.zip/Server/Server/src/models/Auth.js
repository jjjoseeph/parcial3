cat > models/Auth.js << 'EOF'
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');

const Auth = sequelize.define('Auth', {
  id: {
    type: DataTypes.UUID,
    primaryKey: true,
    references: {
      model: User,
      key: 'id'
    }
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  tableName: 'auth',
  timestamps: true
});

User.hasOne(Auth, { foreignKey: 'id' });
Auth.belongsTo(User, { foreignKey: 'id' });

module.exports = Auth;
EOF

models/Role.js
cat > models/Role.js << 'EOF'
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Role = sequelize.define('Role', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'roles',
  timestamps: true
});

module.exports = Role;
EOF
