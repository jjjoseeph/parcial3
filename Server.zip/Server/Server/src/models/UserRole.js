cat > models/UserRole.js << 'EOF'
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');
const Role = require('./role');

const UserRole = sequelize.define('UserRole', {
  user_id: {
    type: DataTypes.UUID,
    references: {
      model: User,
      key: 'id'
    }
  },
  role_id: {
    type: DataTypes.UUID,
    references: {
      model: Role,
      key: 'id'
    }
  }
}, {
  tableName: 'user_roles',
  timestamps: false
});

User.belongsToMany(Role, { through: UserRole, foreignKey: 'user_id' });
Role.belongsToMany(User, { through: UserRole, foreignKey: 'role_id' });

module.exports = UserRole;
EOF


